import React, { Component } from "react";

class Tags extends Component {
  state = {};
  render() {
    return <h1>Tags</h1>;
  }
}

export default Tags;
